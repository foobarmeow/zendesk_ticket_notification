:warning: *Use of this software is subject to important terms and conditions as set forth in the License file* :warning: 

# Answer Suggestions App 

This is the Answer Suggestions App for New Zendesk. The app relies on APIs provided by Zendesk to display suggestions of Knowledge-base articles and topics for your end-user. It is available to all Zendesk accounts via the app marketplace. Please submit bug reports to [Zendesk](https://support.zendesk.com/requests/new). Pull requests are welcome.
