(function() {
    return {
        events: {
            "app.activated": "hidey",
            "ticket.custom_field_22587010.changed": "ticketGraded"
        },
        hidey: function() {
            var currentUserRole = this.currentUser().role();
            var gradedByField = this.ticketFields('custom_field_22551514');
            var gradedField = this.ticketFields('custom_field_22587010');

            if (currentUserRole == 533295 || currentUserRole == 519335) {
                gradedByField.hide();
                gradedField.disable();
            }
            console.log(gradedByField);
        },
        ticketGraded: function() {
            var gradedByField = this.ticketFields('custom_field_22551514');
            gradedByField.disable();
            var ticket = this.ticket();
            var currentUser = this.currentUser().name();
            if (ticket.customField('custom_field_22587010') != null) {
                ticket.customField("custom_field_22551514", currentUser);
            } else {
                ticket.customField("custom_field_22551514", null);
            }
        }
    };
})();